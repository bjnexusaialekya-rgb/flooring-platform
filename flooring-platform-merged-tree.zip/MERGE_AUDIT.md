# Merge audit — phase04-search-retheme

Branch built off `main` @ `5353e67` (last pushed commit: login page layout fix).
Two commits, applied in order:

## 1. `d6ff3dd` — Phase 4 + QBO fix + re-theme (from `trestle-install-current.zip`)

- Installers/vendors: new tables (migration `008_installers_vendors.sql` +
  `schema.sql`), `installerRoutes.js`/`vendorRoutes.js`, `InstallersPage.tsx`/
  `VendorsPage.tsx`, `work_orders.installer_id` / `purchase_orders.vendor_id` FKs.
- `purchaseOrderRoutes.js` / `reportRoutes.js`: **three-way merged**, not
  overwritten — repo's existing endpoints got vendor join / MoM revenue delta
  / overdue count / revenue trend added on top, nothing already there was lost.
- **QBO bug fix**: `qboSyncWorker.js` was reading a static `QBO_REALM_ID` env
  var that's never set anywhere — sync silently failed after every successful
  "Connect to QuickBooks". Now resolves the realm dynamically from
  `qbo_tokens` (`getActiveRealmId()`). No `.env` change needed beyond the
  existing OAuth connect flow.
- Cream/lime/green re-theme: `index.css` tokens, `UIState.tsx` MetricCard
  icon-chip/trend system, `ReportsPage.tsx` (donut + revenue trend line).
  Contrast-verified: CTA gradient corrected from 2.55:1/3.4:1 to
  4.84:1/6.14:1 (WCAG AA needs 4.5:1).

## 2. `3cfa0e2` — Topbar search, export, role-aware columns (from this session)

- Built **on top of** commit 1's topbar restructure (needed the `searchable`
  TopbarConfig flag and `useNavigate` that commit 1 introduced).
- `workOrderRoutes.js`: staff/admin branch extended with `customer_name`,
  `installer_name`, `total_value` (same formula as the dashboard's
  `revenueThisMonth`, so the two numbers can't drift). Client branch verified
  unchanged except property/address columns — **pricing-blind boundary
  intact**, checked line-by-line against `schema.sql` column names.
- `WorkOrdersListPage.tsx`: multi-field search via `useOutletContext`, CSV
  export (from the already role-scoped `filtered` array — can't leak a
  column the API never sent that role), live-count filter tabs, role-gated
  Customer/Installer/Value columns.

## Verification performed (no live Postgres available in this environment)

- ✅ `tsc -b` — clean, zero errors, full frontend including new pages.
- ✅ `oxlint` — 0 errors (2 pre-existing warnings, unrelated files, untouched).
- ✅ All backend route/service files — `node -c` syntax check, clean.
- ✅ Every joined column in the new `workOrderRoutes.js`/`purchaseOrderRoutes.js`
  queries manually cross-checked against `schema.sql` (table/column names,
  not just assumed from memory).
- ✅ Pricing-blind boundary re-confirmed: client-role query branch never
  selects `customer_name`/`total_value`/cost columns.

## Not verified (needs your environment)

- ⬜ Migration `008` has not been run against a live database — no Postgres
  available in this sandbox (apt mirror for postgresql-16 returned 404).
  Run `npm run migrate` (or apply `008_installers_vendors.sql` directly) and
  smoke-test `/installers`, `/vendors`, `/work-orders` before deploying.
- ⬜ QBO sync fix is a logic-level fix, not tested against real QBO OAuth
  tokens — needs your sandbox/live QBO credentials to confirm.
- ⬜ Stripe webhook signature verification and middleware ordering were
  reviewed earlier this session and found correct — carried forward
  unchanged, not re-tested here.

## How to apply

Two patches in the zip, generated with `git format-patch` against your
`main` @ `5353e67`:

```
git checkout main
git pull
git am 0001-Phase-4-installers-vendors-schema-routes-pages-QBO-r.patch
git am 0002-Wire-topbar-search-into-Work-Orders-multi-field-CSV-.patch
```

If `main` has moved past `5353e67`, `git am` will conflict on any file
touched by newer commits — resolve conflict, `git am --continue`. Everything
else applies clean.
